package com.example.swagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
